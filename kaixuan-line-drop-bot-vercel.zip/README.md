# 凱旋歸來｜天堂 LINE 自動掉寶查詢機器人

內建 8,583 筆掉寶資料。

## Vercel
設定環境變數 `LINE_CHANNEL_SECRET`、`LINE_CHANNEL_ACCESS_TOKEN`。

LINE Webhook URL：
`https://你的Vercel網址/api/line/webhook`

開啟 LINE Developers → Messaging API → Use webhook → Verify。

使用者直接輸入怪物名稱或掉落物品即可查詢；只顯示「掉落機率 xx%」，不顯示原始 chance。
