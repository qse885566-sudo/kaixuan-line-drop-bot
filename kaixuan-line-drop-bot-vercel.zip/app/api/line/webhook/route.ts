import crypto from "node:crypto";
import drops from "../../../../data/drops.json";
export const runtime="nodejs";
const SECRET=process.env.LINE_CHANNEL_SECRET;
const TOKEN=process.env.LINE_CHANNEL_ACCESS_TOKEN;
type Drop={monster:string;item:string;chance:number};
const pct=(n:number)=>`${(n/10000).toFixed(4).replace(/\\.?0+$/,"")}%`;
function verify(body:string,sig:string|null){if(!SECRET||!sig)return false;const h=crypto.createHmac("sha256",SECRET).update(body).digest("base64");return crypto.timingSafeEqual(Buffer.from(h),Buffer.from(sig));}
function find(q:string){q=q.trim().toLowerCase();return (drops as Drop[]).filter(d=>d.monster.toLowerCase().includes(q)||d.item.toLowerCase().includes(q));}
async function reply(token:string,messages:any[]){if(!TOKEN)throw Error("LINE_CHANNEL_ACCESS_TOKEN missing");const r=await fetch("https://api.line.me/v2/bot/message/reply",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${TOKEN}`},body:JSON.stringify({replyToken:token,messages})});if(!r.ok)throw Error(`LINE reply ${r.status}: ${await r.text()}`);}
function help(){return "🐉 凱旋歸來｜天堂掉寶查詢\\n\\n直接輸入怪物名稱或掉落物品即可查詢。\\n\\n例如：\\n吸血鬼\\n屠龍劍\\n\\n輸入「幫助」查看此說明。";}
function make(q:string,rs:Drop[]){if(!rs.length)return [{type:"text",text:`找不到「${q}」相關的掉寶資料。`}];const ms=rs.filter(d=>d.monster.toLowerCase().includes(q.toLowerCase()));const is=rs.filter(d=>d.item.toLowerCase().includes(q.toLowerCase()));let s=`🔎 查詢：${q}\\n找到 ${rs.length} 筆資料\\n\\n`;if(ms.length){const g=new Map<string,Drop[]>();ms.forEach(d=>{if(!g.has(d.monster))g.set(d.monster,[]);g.get(d.monster)!.push(d)});for(const [m,ds] of g){s+=`👹 ${m}\\n`;ds.slice(0,50).forEach(d=>s+=`・${d.item}　掉落機率 ${pct(d.chance)}\\n`);s+="\\n";}}if(is.length&&!ms.length){const g=new Map<string,Drop[]>();is.forEach(d=>{if(!g.has(d.item))g.set(d.item,[]);g.get(d.item)!.push(d)});for(const [i,ds] of g){s+=`📦 ${i}\\n`;ds.slice(0,50).forEach(d=>s+=`・${d.monster}　掉落機率 ${pct(d.chance)}\\n`);s+="\\n";}}if(s.length>4500)s=s.slice(0,4400)+"\\n…結果太多，請縮小關鍵字。";return [{type:"text",text:s.trim()}];}
export async function GET(){return Response.json({ok:true,records:(drops as Drop[]).length});}
export async function POST(req:Request){const body=await req.text();if(!verify(body,req.headers.get("x-line-signature")))return new Response("Invalid signature",{status:401});let p:any;try{p=JSON.parse(body)}catch{return new Response("Invalid JSON",{status:400})}for(const e of p.events??[]){if(e.type!=="message"||e.message?.type!=="text"||!e.replyToken)continue;const q=String(e.message.text??"").trim();if(!q)continue;await reply(e.replyToken,/^(幫助|help|\\/help)$/i.test(q)?[{type:"text",text:help()}]:make(q,find(q)));}return Response.json({ok:true});}
